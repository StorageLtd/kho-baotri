@echo off
cd /d "%~dp0"
start "" "%~dp0LTD-CMMS.exe"
