// Local adapter. No Firebase credentials or SDK.
export const firebaseConfig={databaseURL:'/api/database'};
