Copy your licensed Fwlib64.dll, fwlibe64.dll, fwlib30i64.dll here. No DLLs included.
